# FeeIntel

**Fee intelligence for Clanker tokens on Base.**

Track creator earnings, claimed vs unclaimed fee balances, and token portfolios — powered by the Clanker Public API.

## Features

- **Live dashboard** — trending Clanker tokens with market data and fee balances
- **Token detail** — claimed/unclaimed fees, fee configuration, recent on-chain fee events
- **Creator portfolio** — all tokens launched by a wallet and their fee performance
- **Period filters** — 24h / 7d fee activity views
- **Proxy API** — secure, allowlisted proxy to Clanker endpoints with caching

## Stack

- Next.js 16 (App Router)
- React 19
- TypeScript
- Tailwind CSS 4
- SWR
- Vercel Analytics

## Getting started

### Prerequisites

- Node.js 20+
- [pnpm](https://pnpm.io/) 9+ (project uses `pnpm@12.3.4`)

### Install & run

```bash
pnpm install
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000).

### Build for production

```bash
pnpm build
pnpm start
```

## Project structure

```
app/
  api/clanker/[...path]/   # Proxied Clanker Public API (allowlisted)
  dashboard/               # Ecosystem overview
  token/[address]/         # Token fee detail
  creator/[address]/       # Creator portfolio
  docs/                    # Documentation page
components/                # UI components
lib/
  clanker-api.ts           # Fetch helpers, fee parsing, formatting
  feeintel-data.ts         # Shared types & formatters
public/                    # Static assets
```

## API proxy

Client requests go through `/api/clanker/...` which forwards only allowed paths to `https://www.clanker.world`:

- `tokens/trending`
- `tokens/fetch-deployed-by-address`
- `tokens/0x…/fees`
- `tokens/0x…/market`
- `wallet/0x…/creator-fees`

Responses are cached briefly (`s-maxage=15`).

## Deploy

Deploy to Vercel (or any Next.js host):

```bash
# Example with Vercel CLI
vercel
```

No environment variables are required for the public Clanker API.

## License

Private / use as you see fit. Data is sourced from the Clanker Public API; FeeIntel is an independent analytics frontend.
